# ISP Inventory — Change Log

## 1.0 Release Candidate (2026-10-26)
- Consolidated the editable Windows app and its previous features.
- Fixed team issuance rejecting valid lines due to a non-existent source field.
- Validated source warehouses on receipts and team loading.
- Technical sign-off line uniqueness now supports the same material from separate stock sources. Existing databases migrate automatically.
- Stocktaking adjustments are committed atomically.
- Viewer accounts require a team link and remain read-only.
- Added Windows system-check helper and a source-control ignore file.
- Tested end-to-end API workflow: supplier receipt, team loading, multi-source sign-off approval, material editing and backup.

This is a release candidate, not a certified production system. Full Windows browser testing,
restore drills, concurrent-user load tests, and independent security review remain necessary.
